"""
VEYRA Scanner
Реализует режимы проверки: быстрая, полная, выборочная, файл, папка,
критические системные области. Во время работы сообщает прогресс через
callback (текущий файл, проверено, найдено угроз, время, скорость).
"""

import os
import string
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from core import config
from core.logger import log_event, EVENT_DETECTION, EVENT_SYSTEM
from detection import signatures, heuristics, authenticode
from detection.risk_engine import evaluate, RiskVerdict


@dataclass
class ScanProgress:
    current_file: str = ""
    scanned_count: int = 0
    threats_found: int = 0
    elapsed_seconds: float = 0.0
    files_per_second: float = 0.0


@dataclass
class ScanResultItem:
    path: str
    verdict: RiskVerdict


@dataclass
class ScanSummary:
    scan_type: str
    files_scanned: int
    threats: List[ScanResultItem] = field(default_factory=list)
    duration_seconds: float = 0.0
    stopped_early: bool = False


ProgressCallback = Callable[[ScanProgress], None]

# Расширения, которые вообще стоит проверять содержательно (эвристика PE/скриптов).
# Остальные файлы всё равно хэшируются и проверяются по сигнатурам.
_INTERESTING_EXT = config.EXECUTABLE_EXTENSIONS | config.SCRIPT_EXTENSIONS

_QUICK_SCAN_RELATIVE_DIRS = [
    os.path.join("AppData", "Local", "Temp"),
    "Downloads",
    "Desktop",
    os.path.join("AppData", "Roaming"),
]

_CRITICAL_AREAS_WINDOWS = [
    r"C:\Windows\System32\drivers",
    r"C:\Windows\Temp",
    r"C:\Windows\System32\Tasks",
]


class Scanner:
    def __init__(self, db, quarantine_manager, auto_quarantine: bool = False):
        self.db = db
        self.quarantine_manager = quarantine_manager
        self.auto_quarantine = auto_quarantine
        self._stop_requested = False

    def request_stop(self):
        self._stop_requested = True

    # -- публичные режимы -------------------------------------------------

    def quick_scan(self, progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        home = os.path.expanduser("~")
        paths = [os.path.join(home, d) for d in _QUICK_SCAN_RELATIVE_DIRS]
        paths = [p for p in paths if os.path.isdir(p)]
        return self._run_scan("Быстрая проверка", paths, progress_cb)

    def full_scan(self, progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        roots = self._all_drive_roots()
        return self._run_scan("Полная проверка", roots, progress_cb)

    def custom_scan(self, paths: List[str], progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        return self._run_scan("Выборочная проверка", paths, progress_cb)

    def scan_file(self, path: str, progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        return self._run_scan("Проверка файла", [path], progress_cb)

    def scan_folder(self, path: str, progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        return self._run_scan("Проверка папки", [path], progress_cb)

    def critical_areas_scan(self, progress_cb: Optional[ProgressCallback] = None) -> ScanSummary:
        existing = [p for p in _CRITICAL_AREAS_WINDOWS if os.path.isdir(p)]
        return self._run_scan("Проверка критических системных областей", existing, progress_cb)

    # -- внутреннее --------------------------------------------------------

    def _all_drive_roots(self) -> List[str]:
        if not config.IS_WINDOWS:
            return [os.path.expanduser("~")]
        roots = []
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.isdir(drive):
                roots.append(drive)
        return roots

    def _iter_files(self, roots: List[str]):
        for root in roots:
            if os.path.isfile(root):
                yield root
                continue
            for dirpath, _dirnames, filenames in os.walk(root):
                for fn in filenames:
                    yield os.path.join(dirpath, fn)

    def _run_scan(self, scan_type: str, roots: List[str],
                  progress_cb: Optional[ProgressCallback]) -> ScanSummary:
        self._stop_requested = False
        scan_id = self.db.start_scan_record(scan_type)
        log_event(self.db, EVENT_SYSTEM, f"Запуск: {scan_type}")

        start = time.time()
        scanned = 0
        threats: List[ScanResultItem] = []

        for path in self._iter_files(roots):
            if self._stop_requested:
                break
            verdict = self._evaluate_file(path)
            scanned += 1

            if verdict is not None and verdict.level != config.RISK_SAFE:
                threats.append(ScanResultItem(path=path, verdict=verdict))
                log_event(
                    self.db, EVENT_DETECTION,
                    f"{scan_type}: {path} — {verdict.detect_name} "
                    f"(риск {verdict.score}/100, {verdict.level})",
                    severity="WARNING",
                )
                if self.auto_quarantine and verdict.level in (config.RISK_HIGH, config.RISK_CRITICAL):
                    hashes = signatures.compute_hashes(path)
                    try:
                        self.quarantine_manager.quarantine_file(
                            original_path=path,
                            sha256=hashes.sha256 if hashes else None,
                            reason="; ".join(verdict.reasons),
                            risk_score=verdict.score,
                            risk_level=verdict.level,
                            detect_name=verdict.detect_name or config.DETECT_HEUR_SUSPICIOUS,
                        )
                    except Exception:
                        pass  # уже залогировано внутри quarantine_manager

            if progress_cb and (scanned % 25 == 0 or self._stop_requested):
                elapsed = time.time() - start
                progress_cb(ScanProgress(
                    current_file=path,
                    scanned_count=scanned,
                    threats_found=len(threats),
                    elapsed_seconds=elapsed,
                    files_per_second=scanned / elapsed if elapsed > 0 else 0.0,
                ))

        duration = time.time() - start
        if progress_cb:
            progress_cb(ScanProgress(
                current_file="",
                scanned_count=scanned,
                threats_found=len(threats),
                elapsed_seconds=duration,
                files_per_second=scanned / duration if duration > 0 else 0.0,
            ))

        self.db.finish_scan_record(scan_id, scanned, len(threats), duration)
        log_event(
            self.db, EVENT_SYSTEM,
            f"Завершено: {scan_type}. Проверено файлов: {scanned}, угроз: {len(threats)}, "
            f"время: {duration:.1f} с",
        )

        return ScanSummary(
            scan_type=scan_type, files_scanned=scanned, threats=threats,
            duration_seconds=duration, stopped_early=self._stop_requested,
        )

    def _evaluate_file(self, path: str) -> Optional[RiskVerdict]:
        if not os.path.isfile(path):
            return None
        try:
            if os.path.getsize(path) == 0:
                return None
        except OSError:
            return None

        hashes = signatures.compute_hashes(path)
        if hashes is None:
            return None  # файл недоступен для чтения (нет прав и т.п.) — пропускаем, не гадаем

        sig_match = signatures.check_against_db(self.db, hashes)

        ext = os.path.splitext(path)[1].lower()
        if ext in _INTERESTING_EXT:
            heur = heuristics.analyze_file(path)
        else:
            heur = heuristics.HeuristicResult()

        sig_status = authenticode.STATUS_UNKNOWN
        if ext in config.EXECUTABLE_EXTENSIONS:
            sig_status = authenticode.check_signature(path)

        return evaluate(sig_match, heur, signature_status=sig_status)
