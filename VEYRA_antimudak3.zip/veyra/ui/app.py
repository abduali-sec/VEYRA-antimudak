"""
VEYRA UI
Строгий, минималистичный интерфейс на tkinter. Без анимаций и
декоративных элементов — только функциональные разделы.
"""

import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime

from core import config
from core.logger import get_ui_queue, EVENT_DETECTION, EVENT_BLOCK, EVENT_SYSTEM, EVENT_UPDATE
from scanner.scanner import ScanProgress, ScanSummary
from autostart.autostart import list_autostart_items

# --- цветовая палитра: строгая, без "неонового" стиля ----------------------
BG = "#f2f3f5"
PANEL_BG = "#ffffff"
ACCENT = "#1a3c6e"          # тёмно-синий — спокойный, "корпоративный"
ACCENT_DARK = "#122a4d"
TEXT_PRIMARY = "#1b1f24"
TEXT_SECONDARY = "#5b6572"
OK_COLOR = "#1e7a3d"
WARN_COLOR = "#b8860b"
DANGER_COLOR = "#a3282f"

FONT_TITLE = ("Segoe UI", 20, "bold")
FONT_SUBTITLE = ("Segoe UI", 11)
FONT_NORMAL = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")


def _risk_color(level: str) -> str:
    return {
        config.RISK_SAFE: OK_COLOR,
        config.RISK_SUSPICIOUS: WARN_COLOR,
        config.RISK_HIGH: DANGER_COLOR,
        config.RISK_CRITICAL: DANGER_COLOR,
    }.get(level, TEXT_SECONDARY)


class VeyraApp(tk.Tk):
    def __init__(self, db, scanner, quarantine_manager, realtime_monitor):
        super().__init__()
        self.db = db
        self.scanner = scanner
        self.quarantine_manager = quarantine_manager
        self.realtime_monitor = realtime_monitor

        self.title(config.APP_NAME)
        self.geometry("1040x680")
        self.configure(bg=BG)
        self._setup_style()

        self._build_layout()
        self._refresh_dashboard()
        self.after(400, self._poll_log_queue)

    # -- стиль -----------------------------------------------------------

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", font=FONT_NORMAL, padding=(16, 8))
        style.configure("Treeview", font=FONT_NORMAL, rowheight=24)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        style.configure("Accent.TButton", font=FONT_BOLD)

    # -- каркас ------------------------------------------------------------

    def _build_layout(self):
        header = tk.Frame(self, bg=ACCENT, height=56)
        header.pack(fill="x")
        tk.Label(header, text=config.APP_NAME, font=("Segoe UI", 13, "bold"),
                  bg=ACCENT, fg="white").pack(side="left", padx=16, pady=12)
        self.header_status = tk.Label(header, text="", font=FONT_NORMAL, bg=ACCENT, fg="white")
        self.header_status.pack(side="right", padx=16)

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        self.tab_dashboard = tk.Frame(notebook, bg=BG)
        self.tab_scan = tk.Frame(notebook, bg=BG)
        self.tab_quarantine = tk.Frame(notebook, bg=BG)
        self.tab_autostart = tk.Frame(notebook, bg=BG)
        self.tab_logs = tk.Frame(notebook, bg=BG)

        notebook.add(self.tab_dashboard, text="Главная")
        notebook.add(self.tab_scan, text="Проверка")
        notebook.add(self.tab_quarantine, text="Карантин")
        notebook.add(self.tab_autostart, text="Автозагрузка")
        notebook.add(self.tab_logs, text="Журнал событий")

        self._build_dashboard_tab()
        self._build_scan_tab()
        self._build_quarantine_tab()
        self._build_autostart_tab()
        self._build_logs_tab()

    # -- Главная -----------------------------------------------------------

    def _build_dashboard_tab(self):
        wrapper = tk.Frame(self.tab_dashboard, bg=BG)
        wrapper.pack(fill="both", expand=True, padx=24, pady=24)

        card = tk.Frame(wrapper, bg=PANEL_BG, bd=1, relief="solid")
        card.pack(fill="x", pady=(0, 16))

        self.status_title = tk.Label(card, text="СИСТЕМА ЗАЩИЩЕНА", font=("Segoe UI", 16, "bold"),
                                       bg=PANEL_BG, fg=OK_COLOR)
        self.status_title.pack(pady=(20, 4))
        tk.Label(card, text="Явных угроз не обнаружено", font=FONT_SUBTITLE,
                  bg=PANEL_BG, fg=TEXT_SECONDARY).pack(pady=(0, 20))

        info_frame = tk.Frame(wrapper, bg=BG)
        info_frame.pack(fill="x", pady=(0, 16))

        self.info_labels = {}
        rows = [
            ("realtime", "Защита в реальном времени"),
            ("last_scan", "Последняя проверка"),
            ("db_version", "Версия базы сигнатур"),
            ("detections", "Всего обнаружений"),
        ]
        for i, (key, label) in enumerate(rows):
            row = tk.Frame(info_frame, bg=PANEL_BG, bd=1, relief="solid")
            row.grid(row=i // 2, column=i % 2, sticky="nsew", padx=6, pady=6)
            info_frame.grid_columnconfigure(i % 2, weight=1)
            tk.Label(row, text=label, font=FONT_NORMAL, bg=PANEL_BG, fg=TEXT_SECONDARY).pack(
                anchor="w", padx=14, pady=(10, 0))
            value_lbl = tk.Label(row, text="—", font=FONT_BOLD, bg=PANEL_BG, fg=TEXT_PRIMARY)
            value_lbl.pack(anchor="w", padx=14, pady=(0, 10))
            self.info_labels[key] = value_lbl

        btn = tk.Button(wrapper, text="Проверить систему", font=FONT_BOLD, bg=ACCENT, fg="white",
                          activebackground=ACCENT_DARK, activeforeground="white",
                          relief="flat", padx=20, pady=10,
                          command=lambda: self._start_scan("quick"))
        btn.pack(anchor="w")

    def _refresh_dashboard(self):
        realtime_on = self.realtime_monitor.is_running()
        self.info_labels["realtime"].config(
            text="Включена" if realtime_on else "Отключена",
            fg=OK_COLOR if realtime_on else DANGER_COLOR,
        )
        self.header_status.config(text="Защита включена" if realtime_on else "Защита отключена")

        last_scan = self.db.last_scan_info()
        if last_scan:
            dt = datetime.fromisoformat(last_scan["finished_at"]).strftime("%d.%m.%Y %H:%M")
            self.info_labels["last_scan"].config(text=dt)
        else:
            self.info_labels["last_scan"].config(text="Ещё не выполнялась")

        sig_version = self.db.get_setting("signature_db_version", "0")
        sig_count = self.db.signature_count()
        self.info_labels["db_version"].config(text=f"v{sig_version} ({sig_count} записей)")

        self.info_labels["detections"].config(text=str(self.db.total_detections()))

        threats_now = any(
            e["risk_level"] not in (config.RISK_SAFE,)
            for e in []  # текущих активных угроз в этой упрощённой версии не отслеживаем отдельно от карантина
        )
        active_quarantine = len(self.db.list_quarantine(status="В карантине"))
        if active_quarantine > 0:
            self.status_title.config(text=f"ОБНАРУЖЕНЫ УГРОЗЫ: {active_quarantine} В КАРАНТИНЕ",
                                       fg=DANGER_COLOR)
        else:
            self.status_title.config(text="СИСТЕМА ЗАЩИЩЕНА", fg=OK_COLOR)

        self.after(5000, self._refresh_dashboard)

    # -- Проверка ------------------------------------------------------------

    def _build_scan_tab(self):
        wrapper = tk.Frame(self.tab_scan, bg=BG)
        wrapper.pack(fill="both", expand=True, padx=24, pady=24)

        btn_row = tk.Frame(wrapper, bg=BG)
        btn_row.pack(fill="x", pady=(0, 16))

        def mkbtn(text, cmd):
            return tk.Button(btn_row, text=text, font=FONT_NORMAL, bg=PANEL_BG, fg=TEXT_PRIMARY,
                               relief="solid", bd=1, padx=12, pady=8, command=cmd)

        mkbtn("Быстрая проверка", lambda: self._start_scan("quick")).pack(side="left", padx=4)
        mkbtn("Полная проверка", lambda: self._start_scan("full")).pack(side="left", padx=4)
        mkbtn("Выбрать папку…", self._pick_folder_scan).pack(side="left", padx=4)
        mkbtn("Выбрать файл…", self._pick_file_scan).pack(side="left", padx=4)
        mkbtn("Критические области", lambda: self._start_scan("critical")).pack(side="left", padx=4)
        self.stop_btn = mkbtn("Остановить", self._stop_scan)
        self.stop_btn.pack(side="left", padx=4)
        self.stop_btn.config(state="disabled")

        progress_frame = tk.Frame(wrapper, bg=PANEL_BG, bd=1, relief="solid")
        progress_frame.pack(fill="x", pady=(0, 16))

        self.progress_bar = ttk.Progressbar(progress_frame, mode="indeterminate")
        self.progress_bar.pack(fill="x", padx=16, pady=(16, 8))

        self.progress_label = tk.Label(progress_frame, text="Готово к проверке", font=FONT_NORMAL,
                                         bg=PANEL_BG, fg=TEXT_SECONDARY, anchor="w", justify="left")
        self.progress_label.pack(fill="x", padx=16, pady=(0, 16))

        result_frame = tk.Frame(wrapper, bg=PANEL_BG, bd=1, relief="solid")
        result_frame.pack(fill="both", expand=True)
        tk.Label(result_frame, text="Найденные объекты", font=FONT_BOLD, bg=PANEL_BG,
                  fg=TEXT_PRIMARY).pack(anchor="w", padx=14, pady=(12, 4))

        columns = ("path", "detect", "risk", "score")
        self.scan_tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=12)
        headers = {"path": "Файл", "detect": "Детект", "risk": "Уровень риска", "score": "Балл"}
        widths = {"path": 420, "detect": 220, "risk": 200, "score": 70}
        for c in columns:
            self.scan_tree.heading(c, text=headers[c])
            self.scan_tree.column(c, width=widths[c], anchor="w")
        self.scan_tree.pack(fill="both", expand=True, padx=14, pady=(0, 14))

    def _pick_folder_scan(self):
        folder = filedialog.askdirectory(title="Выберите папку для проверки")
        if folder:
            self._start_scan("folder", path=folder)

    def _pick_file_scan(self):
        file = filedialog.askopenfilename(title="Выберите файл для проверки")
        if file:
            self._start_scan("file", path=file)

    def _start_scan(self, mode: str, path: str = None):
        self.scan_tree.delete(*self.scan_tree.get_children())
        self.progress_bar.start(12)
        self.stop_btn.config(state="normal")

        def worker():
            def on_progress(p: ScanProgress):
                self.after(0, lambda: self._update_progress(p))

            if mode == "quick":
                summary = self.scanner.quick_scan(on_progress)
            elif mode == "full":
                summary = self.scanner.full_scan(on_progress)
            elif mode == "critical":
                summary = self.scanner.critical_areas_scan(on_progress)
            elif mode == "folder":
                summary = self.scanner.scan_folder(path, on_progress)
            elif mode == "file":
                summary = self.scanner.scan_file(path, on_progress)
            else:
                return

            self.after(0, lambda: self._scan_finished(summary))

        threading.Thread(target=worker, daemon=True).start()

    def _stop_scan(self):
        self.scanner.request_stop()

    def _update_progress(self, p: ScanProgress):
        self.progress_label.config(
            text=f"Проверено файлов: {p.scanned_count}   |   Угроз найдено: {p.threats_found}   |   "
                 f"Время: {p.elapsed_seconds:.0f} с   |   Скорость: {p.files_per_second:.0f} файл/с\n"
                 f"Текущий файл: {p.current_file}"
        )

    def _scan_finished(self, summary: ScanSummary):
        self.progress_bar.stop()
        self.stop_btn.config(state="disabled")
        status = "остановлена пользователем" if summary.stopped_early else "завершена"
        self.progress_label.config(
            text=f"Проверка {status}. Проверено файлов: {summary.files_scanned}, "
                 f"угроз найдено: {len(summary.threats)}, время: {summary.duration_seconds:.1f} с"
        )
        for item in summary.threats:
            self.scan_tree.insert("", "end", values=(
                item.path, item.verdict.detect_name or "-", item.verdict.level, item.verdict.score
            ))
        self._refresh_dashboard()
        self._refresh_quarantine()

        if summary.threats:
            self._notify(
                f"Проверка завершена: обнаружено {len(summary.threats)} потенциально опасных объектов."
            )
        else:
            self._notify("Проверка завершена. Угроз не обнаружено.")

    # -- Карантин ------------------------------------------------------------

    def _build_quarantine_tab(self):
        wrapper = tk.Frame(self.tab_quarantine, bg=BG)
        wrapper.pack(fill="both", expand=True, padx=24, pady=24)

        btn_row = tk.Frame(wrapper, bg=BG)
        btn_row.pack(fill="x", pady=(0, 12))

        tk.Button(btn_row, text="Восстановить", font=FONT_NORMAL, relief="solid", bd=1,
                   padx=12, pady=6, command=self._restore_selected).pack(side="left", padx=4)
        tk.Button(btn_row, text="Удалить", font=FONT_NORMAL, relief="solid", bd=1,
                   padx=12, pady=6, command=self._delete_selected).pack(side="left", padx=4)
        tk.Button(btn_row, text="Удалить всё", font=FONT_NORMAL, relief="solid", bd=1,
                   padx=12, pady=6, command=self._delete_all_quarantine).pack(side="left", padx=4)
        tk.Button(btn_row, text="Сведения", font=FONT_NORMAL, relief="solid", bd=1,
                   padx=12, pady=6, command=self._show_quarantine_details).pack(side="left", padx=4)

        columns = ("filename", "detect", "risk", "detected_at", "status")
        self.q_tree = ttk.Treeview(wrapper, columns=columns, show="headings", height=18)
        headers = {"filename": "Файл", "detect": "Детект", "risk": "Уровень риска",
                    "detected_at": "Обнаружено", "status": "Статус"}
        widths = {"filename": 260, "detect": 200, "risk": 180, "detected_at": 160, "status": 120}
        for c in columns:
            self.q_tree.heading(c, text=headers[c])
            self.q_tree.column(c, width=widths[c], anchor="w")
        self.q_tree.pack(fill="both", expand=True)

        self._refresh_quarantine()

    def _refresh_quarantine(self):
        self.q_tree.delete(*self.q_tree.get_children())
        for entry in self.quarantine_manager.list_all():
            dt = datetime.fromisoformat(entry["detected_at"]).strftime("%d.%m.%Y %H:%M")
            self.q_tree.insert("", "end", iid=str(entry["id"]), values=(
                entry["filename"], entry["detect_name"], entry["risk_level"], dt, entry["status"]
            ))

    def _selected_quarantine_id(self):
        sel = self.q_tree.selection()
        return int(sel[0]) if sel else None

    def _restore_selected(self):
        entry_id = self._selected_quarantine_id()
        if entry_id is None:
            return
        if self.quarantine_manager.restore(entry_id):
            self._notify("Объект восстановлен.")
        else:
            messagebox.showerror(config.APP_NAME, "Не удалось восстановить объект.")
        self._refresh_quarantine()

    def _delete_selected(self):
        entry_id = self._selected_quarantine_id()
        if entry_id is None:
            return
        if messagebox.askyesno(config.APP_NAME, "Удалить объект безвозвратно?"):
            self.quarantine_manager.delete(entry_id)
            self._notify("Угроза устранена.")
            self._refresh_quarantine()

    def _delete_all_quarantine(self):
        if messagebox.askyesno(config.APP_NAME, "Удалить все объекты карантина безвозвратно?"):
            self.quarantine_manager.delete_all()
            self._refresh_quarantine()

    def _show_quarantine_details(self):
        entry_id = self._selected_quarantine_id()
        if entry_id is None:
            return
        entry = self.db.get_quarantine_entry(entry_id)
        if not entry:
            return
        text = (
            f"Файл: {entry['filename']}\n"
            f"Исходный путь: {entry['original_path']}\n"
            f"SHA-256: {entry['sha256']}\n"
            f"Обнаружено: {entry['detected_at']}\n"
            f"Детект: {entry['detect_name']}\n"
            f"Риск: {entry['risk_score']}/100 ({entry['risk_level']})\n"
            f"Причина: {entry['reason']}\n"
            f"Статус: {entry['status']}"
        )
        messagebox.showinfo("Сведения об объекте", text)

    # -- Автозагрузка -----------------------------------------------------

    def _build_autostart_tab(self):
        wrapper = tk.Frame(self.tab_autostart, bg=BG)
        wrapper.pack(fill="both", expand=True, padx=24, pady=24)

        tk.Button(wrapper, text="Обновить список", font=FONT_NORMAL, relief="solid", bd=1,
                   padx=12, pady=6, command=self._refresh_autostart).pack(anchor="w", pady=(0, 12))

        columns = ("name", "path", "source", "signature", "risk")
        self.autostart_tree = ttk.Treeview(wrapper, columns=columns, show="headings", height=18)
        headers = {"name": "Название", "path": "Путь", "source": "Источник",
                    "signature": "Подпись", "risk": "Риск"}
        widths = {"name": 160, "path": 340, "source": 180, "signature": 140, "risk": 160}
        for c in columns:
            self.autostart_tree.heading(c, text=headers[c])
            self.autostart_tree.column(c, width=widths[c], anchor="w")
        self.autostart_tree.pack(fill="both", expand=True)
        self.autostart_tree.bind("<<TreeviewSelect>>", self._show_autostart_reason)

        self.autostart_reason_label = tk.Label(wrapper, text="", font=FONT_NORMAL, bg=BG,
                                                  fg=TEXT_SECONDARY, anchor="w", justify="left", wraplength=960)
        self.autostart_reason_label.pack(fill="x", pady=(8, 0))

        self._autostart_items = []
        self._refresh_autostart()

    def _refresh_autostart(self):
        self.autostart_tree.delete(*self.autostart_tree.get_children())
        self._autostart_items = list_autostart_items()
        for i, item in enumerate(self._autostart_items):
            self.autostart_tree.insert("", "end", iid=str(i), values=(
                item.name, item.path, item.source, item.signature_status, item.risk_level
            ))

    def _show_autostart_reason(self, _event):
        sel = self.autostart_tree.selection()
        if not sel:
            return
        item = self._autostart_items[int(sel[0])]
        if item.reasons:
            self.autostart_reason_label.config(
                text="Почему это отмечено: " + "; ".join(item.reasons)
            )
        else:
            self.autostart_reason_label.config(text="Явных признаков риска не обнаружено.")

    # -- Журнал событий --------------------------------------------------

    def _build_logs_tab(self):
        wrapper = tk.Frame(self.tab_logs, bg=BG)
        wrapper.pack(fill="both", expand=True, padx=24, pady=24)

        filter_row = tk.Frame(wrapper, bg=BG)
        filter_row.pack(fill="x", pady=(0, 12))
        tk.Label(filter_row, text="Фильтр:", font=FONT_NORMAL, bg=BG).pack(side="left", padx=(0, 8))

        self.log_filter = tk.StringVar(value="Все")
        options = ["Все", EVENT_DETECTION, EVENT_BLOCK, EVENT_SYSTEM, EVENT_UPDATE]
        filter_menu = ttk.OptionMenu(filter_row, self.log_filter, options[0], *options,
                                       command=lambda _v: self._refresh_logs())
        filter_menu.pack(side="left")

        columns = ("time", "type", "message")
        self.log_tree = ttk.Treeview(wrapper, columns=columns, show="headings", height=20)
        headers = {"time": "Время", "type": "Категория", "message": "Сообщение"}
        widths = {"time": 150, "type": 140, "message": 640}
        for c in columns:
            self.log_tree.heading(c, text=headers[c])
            self.log_tree.column(c, width=widths[c], anchor="w")
        self.log_tree.pack(fill="both", expand=True)

        self._refresh_logs()

    def _refresh_logs(self):
        self.log_tree.delete(*self.log_tree.get_children())
        events = self.db.list_events(event_type=self.log_filter.get())
        for e in events:
            dt = datetime.fromisoformat(e["ts"]).strftime("%d.%m.%Y %H:%M:%S")
            self.log_tree.insert("", "end", values=(dt, e["event_type"], e["message"]))

    def _poll_log_queue(self):
        q = get_ui_queue()
        changed = False
        while not q.empty():
            q.get()
            changed = True
        if changed:
            self._refresh_logs()
        self.after(1000, self._poll_log_queue)

    # -- уведомления -------------------------------------------------------

    def _notify(self, message: str):
        try:
            from plyer import notification
            notification.notify(title=config.APP_NAME, message=message, timeout=5)
        except Exception:
            pass  # если plyer недоступен — уведомление просто не показывается, без выдумывания
