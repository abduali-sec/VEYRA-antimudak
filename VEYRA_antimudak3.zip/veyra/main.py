"""
VEYRA antimudak — точка входа.
Инициализирует ядро (БД, логгер), запускает VEYRA Realtime,
VEYRA Self-Protection и открывает главное окно UI.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import config
from core.database import Database
from core.logger import init_logger, log_event, EVENT_SYSTEM
from core.self_protection import SelfProtectionWatchdog
from quarantine.quarantine import QuarantineManager
from scanner.scanner import Scanner
from realtime.monitor import RealtimeMonitor
from realtime.usb_watch import UsbWatcher
import core.logger as logger_module


def main():
    config.ensure_dirs()
    init_logger()

    db = Database()
    log_event(db, EVENT_SYSTEM, f"{config.APP_NAME} {config.APP_VERSION} запущен")

    quarantine_manager = QuarantineManager(db, logger_module)
    scanner = Scanner(db, quarantine_manager, auto_quarantine=True)

    def on_threat(path, verdict):
        log_event(
            db, logger_module.EVENT_DETECTION,
            f"VEYRA Realtime: угроза {verdict.detect_name} ({path})",
            severity="WARNING",
        )

    realtime_monitor = RealtimeMonitor(db, quarantine_manager, threat_cb=on_threat, auto_quarantine=True)
    realtime_monitor.start()

    usb_watcher = UsbWatcher(db)
    usb_watcher.start()

    self_protection = SelfProtectionWatchdog(db, check_paths=[config.DATA_DIR, config.DB_PATH])
    self_protection.start()

    # UI импортируется здесь, чтобы приложение можно было запускать
    # и без графической подсистемы (например, для сервисного режима в будущем)
    from ui.app import VeyraApp
    app = VeyraApp(db, scanner, quarantine_manager, realtime_monitor)

    def on_close():
        realtime_monitor.stop()
        usb_watcher.stop()
        self_protection.stop()
        db.close()
        app.destroy()

    app.protocol("WM_DELETE_WINDOW", on_close)
    app.mainloop()


if __name__ == "__main__":
    main()
