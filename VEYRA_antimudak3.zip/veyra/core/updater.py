"""
VEYRA Updater

Формат файла обновления — простой подписанный JSON:
{
  "version": 3,
  "signatures": [
    {"hash": "...", "hash_type": "sha256", "detect_name": "VEYRA.Trojan.Generic", "severity": "Критическая угроза"},
    ...
  ]
}
плюс отдельный файл подписи update.sig — подпись Ed25519 от публичного
ключа, зашитого в приложение (VEYRA_PUBLIC_KEY ниже — placeholder,
перед реальным использованием замените на собственный ключ и подписывайте
обновления соответствующим приватным ключом на стороне сервера).

Перед установкой обновление обязательно проверяется:
  1. корректность JSON и обязательных полей;
  2. версия новее текущей;
  3. подпись валидна (если модуль подписи доступен).
Если сервер недоступен или обновление повреждено — VEYRA продолжает
работать на последней локальной базе, ничего не ломая.
"""

import json
import os
from dataclasses import dataclass
from typing import Optional

from core.logger import log_event, EVENT_UPDATE

# Плейсхолдер — публичный ключ для проверки подписи обновлений.
# До того как он будет заменён на реальный, проверка подписи
# помечается как недоступная, а не подделывается.
VEYRA_PUBLIC_KEY_HEX: Optional[str] = None

try:
    import nacl.signing
    import nacl.exceptions
    _HAS_NACL = True
except ImportError:
    _HAS_NACL = False


@dataclass
class UpdateResult:
    applied: bool
    message: str
    new_version: Optional[int] = None
    signatures_added: int = 0


def _verify_signature(payload_bytes: bytes, sig_bytes: bytes) -> bool:
    if not _HAS_NACL or not VEYRA_PUBLIC_KEY_HEX:
        return False  # проверка недоступна — обновление из такого источника отклоняется ниже
    try:
        verify_key = nacl.signing.VerifyKey(bytes.fromhex(VEYRA_PUBLIC_KEY_HEX))
        verify_key.verify(payload_bytes, sig_bytes)
        return True
    except Exception:
        return False


def apply_update_file(db, json_path: str, sig_path: Optional[str] = None,
                       require_signature: bool = True) -> UpdateResult:
    if not os.path.isfile(json_path):
        return UpdateResult(False, "Файл обновления не найден")

    try:
        with open(json_path, "rb") as f:
            raw = f.read()
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError) as e:
        log_event(db, EVENT_UPDATE, f"Обновление отклонено: повреждённый файл ({e})", severity="ERROR")
        return UpdateResult(False, "Файл обновления повреждён или имеет неверный формат")

    if "version" not in data or "signatures" not in data:
        log_event(db, EVENT_UPDATE, "Обновление отклонено: отсутствуют обязательные поля", severity="ERROR")
        return UpdateResult(False, "Некорректный формат файла обновления")

    new_version = int(data["version"])
    current_version = int(db.get_setting("signature_db_version", "0"))
    if new_version <= current_version:
        return UpdateResult(False, f"Установленная база уже актуальна (версия {current_version})")

    if require_signature:
        if not sig_path or not os.path.isfile(sig_path):
            log_event(db, EVENT_UPDATE, "Обновление отклонено: отсутствует файл подписи", severity="ERROR")
            return UpdateResult(False, "Обновление отклонено: не удалось проверить подпись (файл подписи отсутствует)")
        with open(sig_path, "rb") as f:
            sig_bytes = f.read()
        if not _verify_signature(raw, sig_bytes):
            log_event(db, EVENT_UPDATE, "Обновление отклонено: подпись недействительна", severity="ERROR")
            return UpdateResult(False, "Обновление отклонено: подпись недействительна или не может быть проверена")

    added = 0
    for entry in data["signatures"]:
        try:
            db.add_signature(
                hash_value=entry["hash"],
                hash_type=entry.get("hash_type", "sha256"),
                detect_name=entry["detect_name"],
                severity=entry.get("severity", "Критическая угроза"),
                source=os.path.basename(json_path),
            )
            added += 1
        except KeyError:
            continue

    db.set_setting("signature_db_version", str(new_version))
    log_event(db, EVENT_UPDATE, f"База сигнатур обновлена до версии {new_version} ({added} записей)")
    return UpdateResult(True, "Обновление успешно установлено", new_version, added)
