"""
VEYRA Logger
Единая точка журналирования. Пишет в файл (для диагностики/поддержки)
и кладёт структурированные события в БД (для раздела "Журнал событий" в UI).
"""

import logging
import queue
from datetime import datetime

from core import config

# Типы событий журнала — используются как категории/фильтры в UI
EVENT_DETECTION = "Обнаружения"
EVENT_BLOCK = "Блокировки"
EVENT_SYSTEM = "Система"
EVENT_UPDATE = "Обновления"

_ui_queue: "queue.Queue" = queue.Queue()
_file_logger = None


def init_logger():
    global _file_logger
    logger = logging.getLogger("veyra")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        try:
            config.ensure_dirs()
            fh = logging.FileHandler(config.LOG_FILE, encoding="utf-8")
            fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
            logger.addHandler(fh)
        except OSError as e:
            # Честно: если файловый журнал недоступен (нет прав на папку и
            # т.п.), приложение не должно падать целиком из-за этого.
            # Работа продолжается без записи в файл — события всё равно
            # видны в БД и в разделе "Журнал событий" интерфейса.
            fallback = logging.StreamHandler()
            fallback.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
            logger.addHandler(fallback)
            logger.warning(f"Не удалось открыть файл журнала ({config.LOG_FILE}): {e}. "
                            f"Журнал в файл вестись не будет, только в БД и интерфейсе.")
    _file_logger = logger
    return logger


def get_ui_queue() -> "queue.Queue":
    return _ui_queue


def log_event(db, event_type: str, message: str, severity: str = "INFO"):
    """
    Записывает событие в файл, в БД (таблица events) и кладёт в очередь
    для немедленного отображения в UI.
    db может быть None (например, до инициализации БД) — тогда пишем
    только в файл/очередь.
    """
    ts = datetime.now()
    if _file_logger is not None:
        level = getattr(logging, severity, logging.INFO)
        _file_logger.log(level, f"[{event_type}] {message}")

    if db is not None:
        try:
            db.add_event(ts, event_type, message, severity)
        except Exception as e:
            if _file_logger is not None:
                _file_logger.error(f"Не удалось записать событие в БД: {e}")

    _ui_queue.put({
        "time": ts.strftime("%d.%m.%Y %H:%M:%S"),
        "type": event_type,
        "message": message,
        "severity": severity,
    })
