"""
VEYRA Database
Локальная БД на SQLite. Хранит: сигнатуры, объекты карантина, журнал
событий, настройки и статистику. Поддерживает версионирование схемы
и простые миграции.
"""

import sqlite3
import threading
from datetime import datetime

from core import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS signatures (
    hash TEXT PRIMARY KEY,
    hash_type TEXT NOT NULL,       -- sha256 / sha1 / md5
    detect_name TEXT NOT NULL,
    severity TEXT NOT NULL,
    added_at TEXT NOT NULL,
    source TEXT                    -- откуда взята сигнатура (файл обновления)
);

CREATE TABLE IF NOT EXISTS quarantine (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_path TEXT NOT NULL,
    filename TEXT NOT NULL,
    sha256 TEXT,
    detected_at TEXT NOT NULL,
    reason TEXT,
    risk_score INTEGER,
    risk_level TEXT,
    detect_name TEXT,
    quarantine_path TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'В карантине'   -- В карантине / Восстановлен / Удалён
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    event_type TEXT NOT NULL,
    message TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'INFO'
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS scan_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_type TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    files_scanned INTEGER DEFAULT 0,
    threats_found INTEGER DEFAULT 0,
    duration_seconds REAL
);
"""


class Database:
    def __init__(self, path: str = None):
        self.path = path or config.DB_PATH
        config.ensure_dirs()
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    # -- служебное -----------------------------------------------------
    def _init_schema(self):
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.commit()
            cur = self._conn.execute("SELECT value FROM meta WHERE key='schema_version'")
            row = cur.fetchone()
            if row is None:
                self._conn.execute(
                    "INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                    (str(config.SCHEMA_VERSION),),
                )
                self._conn.commit()
            # место для будущих миграций: сравнить row['value'] и SCHEMA_VERSION

    # -- метаданные (внутренние, не пользовательские настройки) ------------
    def get_meta(self, key: str, default=None):
        cur = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else default

    # -- настройки -------------------------------------------------------
    def get_setting(self, key: str, default=None):
        cur = self._conn.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str):
        with self._lock:
            self._conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )
            self._conn.commit()

    # -- сигнатуры ---------------------------------------------------------
    def add_signature(self, hash_value: str, hash_type: str, detect_name: str,
                       severity: str, source: str = "manual"):
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO signatures "
                "(hash, hash_type, detect_name, severity, added_at, source) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (hash_value.lower(), hash_type, detect_name, severity,
                 datetime.now().isoformat(), source),
            )
            self._conn.commit()

    def lookup_signature(self, *hashes: str):
        for h in hashes:
            if not h:
                continue
            cur = self._conn.execute(
                "SELECT * FROM signatures WHERE hash=?", (h.lower(),)
            )
            row = cur.fetchone()
            if row:
                return dict(row)
        return None

    def signature_count(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) AS c FROM signatures")
        return cur.fetchone()["c"]

    # -- карантин ------------------------------------------------------
    def add_quarantine_entry(self, original_path, filename, sha256, reason,
                              risk_score, risk_level, detect_name, quarantine_path):
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO quarantine "
                "(original_path, filename, sha256, detected_at, reason, "
                " risk_score, risk_level, detect_name, quarantine_path) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (original_path, filename, sha256, datetime.now().isoformat(),
                 reason, risk_score, risk_level, detect_name, quarantine_path),
            )
            self._conn.commit()
            return cur.lastrowid

    def list_quarantine(self, status: str = None):
        if status:
            cur = self._conn.execute(
                "SELECT * FROM quarantine WHERE status=? ORDER BY id DESC", (status,)
            )
        else:
            cur = self._conn.execute("SELECT * FROM quarantine ORDER BY id DESC")
        return [dict(r) for r in cur.fetchall()]

    def get_quarantine_entry(self, entry_id: int):
        cur = self._conn.execute("SELECT * FROM quarantine WHERE id=?", (entry_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def update_quarantine_status(self, entry_id: int, status: str):
        with self._lock:
            self._conn.execute(
                "UPDATE quarantine SET status=? WHERE id=?", (status, entry_id)
            )
            self._conn.commit()

    # -- события ---------------------------------------------------------
    def add_event(self, ts: datetime, event_type: str, message: str, severity: str):
        with self._lock:
            self._conn.execute(
                "INSERT INTO events (ts, event_type, message, severity) "
                "VALUES (?, ?, ?, ?)",
                (ts.isoformat(), event_type, message, severity),
            )
            self._conn.commit()

    def list_events(self, event_type: str = None, limit: int = 500):
        if event_type and event_type != "Все":
            cur = self._conn.execute(
                "SELECT * FROM events WHERE event_type=? ORDER BY id DESC LIMIT ?",
                (event_type, limit),
            )
        else:
            cur = self._conn.execute(
                "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
            )
        return [dict(r) for r in cur.fetchall()]

    # -- история сканирований --------------------------------------------
    def start_scan_record(self, scan_type: str) -> int:
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO scan_history (scan_type, started_at) VALUES (?, ?)",
                (scan_type, datetime.now().isoformat()),
            )
            self._conn.commit()
            return cur.lastrowid

    def finish_scan_record(self, scan_id: int, files_scanned: int,
                            threats_found: int, duration_seconds: float):
        with self._lock:
            self._conn.execute(
                "UPDATE scan_history SET finished_at=?, files_scanned=?, "
                "threats_found=?, duration_seconds=? WHERE id=?",
                (datetime.now().isoformat(), files_scanned, threats_found,
                 duration_seconds, scan_id),
            )
            self._conn.commit()

    def last_scan_info(self):
        cur = self._conn.execute(
            "SELECT * FROM scan_history WHERE finished_at IS NOT NULL "
            "ORDER BY id DESC LIMIT 1"
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def total_detections(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) AS c FROM quarantine")
        return cur.fetchone()["c"]

    def close(self):
        self._conn.close()
