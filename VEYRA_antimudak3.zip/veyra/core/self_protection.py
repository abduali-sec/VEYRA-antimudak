"""
VEYRA Self-Protection

Честно о границах: настоящая защита антивируса от остановки/удаления
в промышленных продуктах реализуется через service SERVICE_ALL_ACCESS
ACL-ограничения, защищённые процессы (PPL) и минифильтр-драйвер —
это требует подписанного драйвера и установки как защищённая служба
Windows, что выходит за рамки обычного exe-приложения.

Здесь реализован честный user-mode вариант:
  - при работе как служба Windows используются штатные ACL службы,
    ограничивающие остановку/изменение конфигурации не-администраторами
    (см. install_service.ps1 в комплекте);
  - watchdog-поток отслеживает, что процесс/поток защиты жив, и
    фиксирует в журнале сам факт остановки защиты, если процесс
    завершается не штатно (это обнаружение постфактум, а не блокировка
    в момент попытки — так и указано в интерфейсе).

Никаких скрытых механизмов закрепления, обхода UAC или сокрытия
процесса здесь нет и не будет — это противоречило бы требованиям.
"""

import os
import threading
import time

from core.logger import log_event, EVENT_SYSTEM


class SelfProtectionWatchdog:
    """Периодически проверяет собственную целостность (наличие каталога
    данных, доступность БД) и фиксирует в журнале, если что-то не так —
    например, каталог программы или БД стали недоступны/удалены."""

    def __init__(self, db, check_paths, interval: float = 30.0):
        self.db = db
        self.check_paths = list(check_paths)
        self.interval = interval
        self._running = False

    def start(self):
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            for path in self.check_paths:
                if not os.path.exists(path):
                    log_event(
                        self.db, EVENT_SYSTEM,
                        f"Внимание: компонент защиты недоступен ({path}). "
                        f"Возможна попытка вмешательства в работу VEYRA.",
                        severity="CRITICAL",
                    )
            time.sleep(self.interval)
