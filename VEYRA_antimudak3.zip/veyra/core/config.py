"""
VEYRA Core / Config
Центральные пути и константы приложения.
"""

import os
import sys

APP_NAME = "VEYRA antimudak"
APP_VERSION = "0.1.0"
SCHEMA_VERSION = 1

# --- Каталоги данных -------------------------------------------------------
# Изначально данные хранились в %PROGRAMDATA%\VEYRA — по замыслу это удобно
# для будущей работы как службы, доступной всем пользователям. На практике
# эта папка на многих машинах недоступна для записи обычному пользователю
# без прав администратора (UAC/политики/антивирус), и приложение падало
# с PermissionError. Поэтому по умолчанию используется папка текущего
# пользователя (%LOCALAPPDATA%\VEYRA), куда права на запись есть всегда,
# без повышения прав. Функция проверяет каждый вариант на реальную
# возможность записи и берёт первый подходящий — вместо того чтобы
# предполагать это и падать позже.

def _can_write(path: str) -> bool:
    try:
        os.makedirs(path, exist_ok=True)
        probe = os.path.join(path, ".write_test")
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
        return True
    except OSError:
        return False


def _base_data_dir() -> str:
    import tempfile
    candidates = []
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        candidates.append(os.path.join(local_appdata, "VEYRA"))
    appdata = os.environ.get("APPDATA")
    if appdata:
        candidates.append(os.path.join(appdata, "VEYRA"))
    program_data = os.environ.get("PROGRAMDATA")
    if program_data:
        candidates.append(os.path.join(program_data, "VEYRA"))
    candidates.append(os.path.join(os.path.expanduser("~"), ".veyra"))
    candidates.append(os.path.join(tempfile.gettempdir(), "VEYRA"))

    for candidate in candidates:
        if _can_write(candidate):
            return candidate
    # ни один вариант не подтверждён как доступный для записи —
    # возвращаем последний кандидат; ensure_dirs()/логгер обработают
    # возможную ошибку записи явно, не притворяясь, что всё в порядке
    return candidates[-1]


DATA_DIR = _base_data_dir()
DB_PATH = os.path.join(DATA_DIR, "veyra.db")
QUARANTINE_DIR = os.path.join(DATA_DIR, "quarantine")
LOG_DIR = os.path.join(DATA_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "veyra.log")
SIGNATURE_UPDATE_DIR = os.path.join(DATA_DIR, "updates")


def ensure_dirs():
    for d in (DATA_DIR, QUARANTINE_DIR, LOG_DIR, SIGNATURE_UPDATE_DIR):
        os.makedirs(d, exist_ok=True)


IS_WINDOWS = sys.platform.startswith("win")

# --- Категории детектов ------------------------------------------------
# Названия детектов должны объяснять категорию угрозы, а не быть
# бессмысленными формулировками.
DETECT_TROJAN_GENERIC = "VEYRA.Trojan.Generic"
DETECT_RANSOMWARE_BEHAVIOR = "VEYRA.Ransomware.Behavior"
DETECT_SUSPICIOUS_SCRIPT = "VEYRA.Suspicious.Script"
DETECT_BACKDOOR_GENERIC = "VEYRA.Backdoor.Generic"
DETECT_PUA_GENERIC = "VEYRA.PUA.Generic"
DETECT_MINER_BEHAVIOR = "VEYRA.Miner.Behavior"
DETECT_HEUR_SUSPICIOUS = "VEYRA.Heur.Suspicious"
DETECT_KNOWN_MALWARE = "VEYRA.Signature.Match"

# --- Уровни риска (система оценки, единая для всего приложения) -------
RISK_SAFE = "Безопасно"
RISK_SUSPICIOUS = "Подозрительно"
RISK_HIGH = "Высокая вероятность угрозы"
RISK_CRITICAL = "Критическая угроза"


def risk_level_from_score(score: int) -> str:
    if score < 30:
        return RISK_SAFE
    if score < 60:
        return RISK_SUSPICIOUS
    if score < 80:
        return RISK_HIGH
    return RISK_CRITICAL


# Папки, которые чаще всего являются источником заражения —
# используются эвристикой и автозагрузкой для повышения риска,
# а НЕ как единственное основание для вердикта.
SUSPICIOUS_LOCATION_HINTS = (
    "\\appdata\\local\\temp\\",
    "\\appdata\\roaming\\",
    "\\downloads\\",
    "\\programdata\\",
    "\\public\\",
)

EXECUTABLE_EXTENSIONS = {
    ".exe", ".dll", ".sys", ".scr", ".com", ".cpl", ".msi", ".msp",
}
SCRIPT_EXTENSIONS = {
    ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta",
}
