"""
VEYRA Realtime

Честно о границах: это защита УРОВНЯ ПОЛЬЗОВАТЕЛЬСКОГО ПРОЦЕССА
(user-mode), а не драйвер файловой системы ядра (minifilter), который
используют промышленные антивирусы для перехвата операций ДО их
выполнения. Здесь используется:
  - watchdog (ReadDirectoryChangesW через Windows API) для быстрой
    реакции на создание/изменение файлов в наблюдаемых папках;
  - периодический опрос новых процессов через psutil.

Это не «проверка перед запуском» в строгом смысле (файл технически
может успеть запуститься до завершения анализа), а реакция в течение
долей секунды — секунд после события. Об этом ограничении сказано в UI.
"""

import os
import threading
import time
from collections import defaultdict, deque
from typing import Callable, Optional

import psutil
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from core import config
from core.logger import log_event, EVENT_DETECTION, EVENT_SYSTEM
from detection import signatures, heuristics, authenticode
from detection.risk_engine import evaluate, RiskVerdict

WATCHED_RELATIVE_DIRS = [
    "Downloads", "Desktop",
    os.path.join("AppData", "Local", "Temp"),
]

# известные защитные продукты/процессы Windows — попытка их остановки
# сторонним процессом сама по себе не анализируется этим модулем (это
# делает VEYRA Self-Protection), здесь только файловые и процессные события.

PROCESS_POLL_INTERVAL = 3.0
BURST_WINDOW_SECONDS = 30
BURST_FILE_THRESHOLD = 50  # изменений пользовательских файлов за окно — похоже на ransomware


ThreatCallback = Callable[[str, RiskVerdict], None]


class _FsHandler(FileSystemEventHandler):
    def __init__(self, monitor: "RealtimeMonitor"):
        self._monitor = monitor

    def on_created(self, event):
        if not event.is_directory:
            self._monitor.queue_path(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._monitor.note_modification(event.src_path)


class RealtimeMonitor:
    def __init__(self, db, quarantine_manager, threat_cb: Optional[ThreatCallback] = None,
                 auto_quarantine: bool = True):
        self.db = db
        self.quarantine_manager = quarantine_manager
        self.threat_cb = threat_cb
        self.auto_quarantine = auto_quarantine

        self._observer: Optional[Observer] = None
        self._running = False
        self._known_pids = set()

        self._mod_events = deque()  # (timestamp, path) — для детекта "всплеска"

    # -- запуск/остановка ---------------------------------------------------

    def start(self):
        if self._running:
            return
        self._running = True
        self._known_pids = {p.pid for p in psutil.process_iter()}

        self._observer = Observer()
        handler = _FsHandler(self)
        home = os.path.expanduser("~")
        watched_any = False
        for rel in WATCHED_RELATIVE_DIRS:
            path = os.path.join(home, rel)
            if os.path.isdir(path):
                self._observer.schedule(handler, path, recursive=True)
                watched_any = True
        if watched_any:
            self._observer.start()

        threading.Thread(target=self._process_poll_loop, daemon=True).start()
        log_event(self.db, EVENT_SYSTEM, "Защита в реальном времени включена")

    def stop(self):
        self._running = False
        if self._observer is not None:
            self._observer.stop()
            self._observer.join(timeout=2)
        log_event(self.db, EVENT_SYSTEM, "Защита в реальном времени отключена")

    def is_running(self) -> bool:
        return self._running

    # -- обработка файловых событий -----------------------------------------

    def queue_path(self, path: str):
        threading.Thread(target=self._check_new_file, args=(path,), daemon=True).start()

    def note_modification(self, path: str):
        now = time.time()
        self._mod_events.append((now, path))
        while self._mod_events and now - self._mod_events[0][0] > BURST_WINDOW_SECONDS:
            self._mod_events.popleft()

        unique_files = {p for _, p in self._mod_events}
        if len(unique_files) >= BURST_FILE_THRESHOLD:
            self._mod_events.clear()
            fake_sig = signatures.SignatureMatch(matched=False)
            heur = heuristics.HeuristicResult()
            verdict = evaluate(
                fake_sig, heur,
                behavior_flags=[
                    f"массовое изменение пользовательских файлов "
                    f"({len(unique_files)} файлов за {BURST_WINDOW_SECONDS} с) — "
                    f"характерно для поведения программ-вымогателей"
                ],
            )
            verdict.detect_name = config.DETECT_RANSOMWARE_BEHAVIOR
            log_event(
                self.db, EVENT_DETECTION,
                f"Обнаружена массовая активность изменения файлов — {verdict.detect_name}",
                severity="CRITICAL",
            )
            if self.threat_cb:
                self.threat_cb(path, verdict)

    def _check_new_file(self, path: str):
        # небольшая задержка, чтобы файл дописался на диск перед хэшированием
        time.sleep(0.3)
        if not os.path.isfile(path):
            return
        ext = os.path.splitext(path)[1].lower()
        if ext not in (config.EXECUTABLE_EXTENSIONS | config.SCRIPT_EXTENSIONS):
            return  # не проверяем содержательно каждый созданный файл подряд — только исполняемые/скрипты

        hashes = signatures.compute_hashes(path)
        if hashes is None:
            return
        sig_match = signatures.check_against_db(self.db, hashes)
        heur = heuristics.analyze_file(path)
        sig_status = authenticode.check_signature(path) if ext in config.EXECUTABLE_EXTENSIONS \
            else authenticode.STATUS_UNKNOWN

        verdict = evaluate(sig_match, heur, signature_status=sig_status)
        if verdict.level == config.RISK_SAFE:
            return

        log_event(
            self.db, EVENT_DETECTION,
            f"Новый файл: {path} — {verdict.detect_name} (риск {verdict.score}/100)",
            severity="WARNING",
        )

        if self.auto_quarantine and verdict.level in (config.RISK_HIGH, config.RISK_CRITICAL):
            try:
                self.quarantine_manager.quarantine_file(
                    original_path=path, sha256=hashes.sha256,
                    reason="; ".join(verdict.reasons), risk_score=verdict.score,
                    risk_level=verdict.level, detect_name=verdict.detect_name,
                )
            except Exception:
                pass

        if self.threat_cb:
            self.threat_cb(path, verdict)

    # -- обработка процессов ------------------------------------------------

    def _process_poll_loop(self):
        while self._running:
            try:
                current = {p.pid: p for p in psutil.process_iter(["pid", "name", "exe", "cmdline"])}
                new_pids = set(current) - self._known_pids
                for pid in new_pids:
                    self._check_new_process(current[pid])
                self._known_pids = set(current)
            except Exception as e:
                log_event(self.db, EVENT_SYSTEM, f"Ошибка мониторинга процессов: {e}", severity="ERROR")
            time.sleep(PROCESS_POLL_INTERVAL)

    def _check_new_process(self, proc: psutil.Process):
        try:
            info = proc.info
            cmdline = " ".join(info.get("cmdline") or [])
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return

        flags = []
        lowered = cmdline.lower()
        if "-enc" in lowered or "-encodedcommand" in lowered:
            flags.append("запуск с закодированной командой (EncodedCommand)")
        if "-windowstyle hidden" in lowered or "-w hidden" in lowered:
            flags.append("запуск в скрытом окне")
        if "bypass" in lowered and "executionpolicy" in lowered:
            flags.append("обход политики выполнения скриптов")

        exe = info.get("exe") or ""
        if exe:
            norm = exe.lower().replace("/", "\\")
            for hint in config.SUSPICIOUS_LOCATION_HINTS:
                if hint in norm:
                    flags.append(f"процесс запущен из каталога {hint.strip(chr(92))}")
                    break

        if not flags:
            return

        fake_sig = signatures.SignatureMatch(matched=False)
        heur = heuristics.HeuristicResult()
        verdict = evaluate(fake_sig, heur, behavior_flags=flags)

        if verdict.level == config.RISK_SAFE:
            return

        log_event(
            self.db, EVENT_DETECTION,
            f"Подозрительный процесс: {info.get('name')} (PID {info.get('pid')}) — "
            f"{verdict.detect_name}. Причины: {', '.join(flags)}",
            severity="WARNING",
        )
        if self.threat_cb:
            self.threat_cb(exe or info.get("name", ""), verdict)
