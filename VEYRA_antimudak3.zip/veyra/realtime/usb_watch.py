"""
VEYRA — проверка USB и внешних носителей.
Опрашивает список логических дисков через psutil и обнаруживает новые
съёмные разделы. Не запускает автоматически ничего с накопителя —
только предлагает проверку и показывает результат.
"""

import os
import threading
import time
from typing import Callable, Optional

import psutil

from core import config
from core.logger import log_event, EVENT_SYSTEM

NewDriveCallback = Callable[[str], None]


class UsbWatcher:
    def __init__(self, db, on_new_drive: Optional[NewDriveCallback] = None, interval: float = 3.0):
        self.db = db
        self.on_new_drive = on_new_drive
        self.interval = interval
        self._running = False
        self._known = set()

    def start(self):
        self._running = True
        self._known = self._removable_drives()
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._running = False

    def _removable_drives(self):
        drives = set()
        for part in psutil.disk_partitions(all=False):
            opts = part.opts.lower() if part.opts else ""
            # на Windows psutil не всегда явно помечает removable — используем
            # эвристику по drivetype через ctypes, если доступно
            if config.IS_WINDOWS:
                if _is_removable_windows(part.device):
                    drives.add(part.device)
            elif "removable" in opts:
                drives.add(part.device)
        return drives

    def _loop(self):
        while self._running:
            current = self._removable_drives()
            new = current - self._known
            for drive in new:
                log_event(
                    self.db, EVENT_SYSTEM,
                    f"Обнаружен новый съёмный накопитель: {drive}. Рекомендуется проверка.",
                )
                if self.on_new_drive:
                    self.on_new_drive(drive)
            self._known = current
            time.sleep(self.interval)


def _is_removable_windows(device: str) -> bool:
    try:
        import ctypes
        drive_type = ctypes.windll.kernel32.GetDriveTypeW(device)
        DRIVE_REMOVABLE = 2
        return drive_type == DRIVE_REMOVABLE
    except Exception:
        return False


def list_executables_and_autorun(drive: str):
    """Возвращает список исполняемых файлов верхнего уровня и файл
    autorun.inf (если есть) на накопителе, для последующей проверки
    через Scanner.scan_folder / scan_file."""
    result = {"executables": [], "autorun_inf": None}
    if not os.path.isdir(drive):
        return result
    try:
        for entry in os.listdir(drive):
            full = os.path.join(drive, entry)
            if entry.lower() == "autorun.inf":
                result["autorun_inf"] = full
            elif os.path.splitext(entry)[1].lower() in config.EXECUTABLE_EXTENSIONS:
                result["executables"].append(full)
    except (OSError, PermissionError):
        pass
    return result
