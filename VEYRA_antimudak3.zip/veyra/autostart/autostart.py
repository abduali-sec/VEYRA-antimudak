"""
VEYRA Autostart
Перечисляет распространённые механизмы автозапуска Windows: разделы
реестра Run/RunOnce (HKCU и HKLM) и папку "Автозагрузка". Для каждого
элемента показывает название, путь, издателя (если удаётся получить),
статус цифровой подписи и уровень риска с объяснением.
"""

import os
from dataclasses import dataclass, field
from typing import List

from core import config
from detection import authenticode

try:
    import winreg
    _HAS_WINREG = True
except ImportError:
    _HAS_WINREG = False

_REGISTRY_RUN_KEYS = [
    (r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU"),
    (r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU"),
]
_REGISTRY_RUN_KEYS_HKLM = [
    (r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM"),
    (r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM"),
]


@dataclass
class AutostartItem:
    name: str
    path: str
    source: str  # например "Реестр (HKCU\\...\\Run)" или "Папка автозагрузки"
    publisher: str = "Неизвестен"
    signature_status: str = authenticode.STATUS_UNKNOWN
    risk_score: int = 0
    risk_level: str = config.RISK_SAFE
    reasons: List[str] = field(default_factory=list)


def _extract_exe_path(command: str) -> str:
    command = command.strip()
    if command.startswith('"'):
        end = command.find('"', 1)
        if end != -1:
            return command[1:end]
    return command.split(" ")[0]


def _score_item(exe_path: str, signature_status: str) -> (int, List[str]):
    score = 0
    reasons = []
    norm = exe_path.lower().replace("/", "\\")

    if not os.path.isfile(exe_path):
        score += 15
        reasons.append("исполняемый файл не найден по указанному пути")
        return score, reasons

    for hint in config.SUSPICIOUS_LOCATION_HINTS:
        if hint in norm:
            score += 15
            reasons.append(f"расположен во временном/пользовательском каталоге ({hint.strip(chr(92))})")
            break

    if signature_status == authenticode.STATUS_INVALID:
        score += 25
        reasons.append("цифровая подпись недействительна")
    elif signature_status == authenticode.STATUS_UNSIGNED:
        score += 8
        reasons.append("файл не подписан (само по себе не является угрозой)")

    return min(score, 70), reasons


def _registry_items(hive_name: str, subkey: str) -> List[AutostartItem]:
    items = []
    if not _HAS_WINREG:
        return items
    hive = winreg.HKEY_CURRENT_USER if hive_name == "HKCU" else winreg.HKEY_LOCAL_MACHINE
    try:
        key = winreg.OpenKey(hive, subkey)
    except OSError:
        return items

    i = 0
    while True:
        try:
            name, value, _ = winreg.EnumValue(key, i)
        except OSError:
            break
        i += 1
        exe_path = _extract_exe_path(value)
        sig_status = authenticode.check_signature(exe_path) if os.path.isfile(exe_path) \
            else authenticode.STATUS_UNKNOWN
        score, reasons = _score_item(exe_path, sig_status)
        items.append(AutostartItem(
            name=name, path=value,
            source=f"Реестр ({hive_name}\\{subkey})",
            signature_status=sig_status,
            risk_score=score,
            risk_level=config.risk_level_from_score(score),
            reasons=reasons,
        ))
    winreg.CloseKey(key)
    return items


def _startup_folder_items() -> List[AutostartItem]:
    items = []
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return items
    folder = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
    if not os.path.isdir(folder):
        return items
    for fn in os.listdir(folder):
        full = os.path.join(folder, fn)
        sig_status = authenticode.check_signature(full) if os.path.isfile(full) \
            else authenticode.STATUS_UNKNOWN
        score, reasons = _score_item(full, sig_status)
        items.append(AutostartItem(
            name=fn, path=full, source="Папка автозагрузки",
            signature_status=sig_status, risk_score=score,
            risk_level=config.risk_level_from_score(score), reasons=reasons,
        ))
    return items


def list_autostart_items() -> List[AutostartItem]:
    items: List[AutostartItem] = []
    for subkey, hive in _REGISTRY_RUN_KEYS:
        items.extend(_registry_items(hive, subkey))
    for subkey, hive in _REGISTRY_RUN_KEYS_HKLM:
        items.extend(_registry_items(hive, subkey))
    items.extend(_startup_folder_items())
    return items
