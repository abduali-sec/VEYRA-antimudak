"""
VEYRA Risk Engine
Объединяет сигнатурный результат, эвристику, сведения о цифровой подписи
и (опционально) поведенческие флаги от VEYRA Realtime в единый,
объяснимый итоговый уровень риска с перечнем причин.
"""

from dataclasses import dataclass, field
from typing import List, Optional

from core import config
from detection.signatures import SignatureMatch
from detection.heuristics import HeuristicResult


@dataclass
class RiskVerdict:
    score: int
    level: str
    detect_name: Optional[str]
    reasons: List[str] = field(default_factory=list)
    signature_match: bool = False
    pe_analyzed: bool = False


def _pick_detect_name(signature_match: SignatureMatch, heuristic: HeuristicResult,
                       behavior_flags: List[str], score: int) -> Optional[str]:
    if signature_match.matched:
        return signature_match.detect_name

    if score < 30:
        return None

    joined = " ".join(heuristic.reasons + behavior_flags).lower()

    if any("шифрован" in f.lower() or "массовое изменение" in f.lower() for f in behavior_flags):
        return config.DETECT_RANSOMWARE_BEHAVIOR
    if "майнер" in joined or "miner" in joined or "xmrig" in joined:
        return config.DETECT_MINER_BEHAVIOR
    if "внедрени" in joined or "remote thread" in joined.replace(" ", ""):
        return config.DETECT_BACKDOOR_GENERIC
    if any(r for r in heuristic.reasons if "скрипт" in r.lower()) or \
       any(r for r in heuristic.reasons if "powershell" in r.lower() or "iex" in r.lower()):
        return config.DETECT_SUSPICIOUS_SCRIPT
    if score >= 60:
        return config.DETECT_TROJAN_GENERIC
    return config.DETECT_HEUR_SUSPICIOUS


def evaluate(signature_match: SignatureMatch, heuristic: HeuristicResult,
             signature_status: str = "Не проверено",
             behavior_flags: Optional[List[str]] = None) -> RiskVerdict:
    """
    signature_status: "Подписан" / "Не подписан" / "Подпись недействительна" / "Не проверено"
    behavior_flags: список описаний подозрительного поведения от VEYRA Realtime
                     (например "массовое изменение пользовательских файлов")
    """
    behavior_flags = behavior_flags or []
    reasons: List[str] = []
    score = 0

    if signature_match.matched:
        # прямое совпадение по базе — максимальный приоритет
        score = 100
        reasons.append(f"совпадение по базе известных угроз (хэш {signature_match.matched_hash[:12]}…)")
    else:
        score += heuristic.score
        reasons.extend(heuristic.reasons)

        for flag in behavior_flags:
            score += 20
            reasons.append(flag)

        # отсутствие подписи само по себе НЕ является основанием для вердикта —
        # оно лишь немного повышает балл, только если есть другие признаки
        if signature_status == "Подпись недействительна":
            score += 15
            reasons.append("цифровая подпись файла недействительна")
        elif signature_status == "Не подписан" and score > 0:
            score += 5
            reasons.append("файл не имеет цифровой подписи (в сочетании с другими признаками)")

    score = max(0, min(100, score))
    level = config.risk_level_from_score(score)
    detect_name = _pick_detect_name(signature_match, heuristic, behavior_flags, score)

    return RiskVerdict(
        score=score,
        level=level,
        detect_name=detect_name,
        reasons=reasons or ["признаков угрозы не обнаружено"],
        signature_match=signature_match.matched,
        pe_analyzed=heuristic.pe_analyzed,
    )
