"""
VEYRA Heuristic
Эвристический анализ файлов. Каждый признак даёт ограниченный вклад
в общий балл — ни один отдельный признак не объявляет файл вредоносным
сам по себе (см. VEYRA Risk Engine).

Для анализа PE-файлов (.exe/.dll/...) используется библиотека pefile,
если она установлена. Если pefile недоступен, PE-эвристика честно
пропускается (а не подделывается), об этом сообщается в результате.
"""

import math
import os
import re
from dataclasses import dataclass, field
from typing import List

from core import config

try:
    import pefile  # type: ignore
    _HAS_PEFILE = True
except ImportError:
    _HAS_PEFILE = False


@dataclass
class HeuristicResult:
    score: int = 0
    reasons: List[str] = field(default_factory=list)
    pe_analyzed: bool = False

    def add(self, points: int, reason: str):
        self.score += points
        self.reasons.append(reason)


COMMON_SUSPICIOUS_IMPORTS = {
    # комбинация этих функций типична для инъекции кода в чужой процесс
    "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread",
    "SetWindowsHookEx", "NtUnmapViewOfSection",
}

PACKER_SECTION_NAMES = {"upx0", "upx1", "upx2", ".aspack", ".vmp0", ".vmp1", ".themida"}

SUSPICIOUS_SCRIPT_PATTERNS = [
    (re.compile(rb"IEX\s*\(", re.IGNORECASE), "вызов Invoke-Expression (IEX) в скрипте"),
    (re.compile(rb"-EncodedCommand", re.IGNORECASE), "запуск PowerShell с закодированной командой"),
    (re.compile(rb"DownloadString|DownloadFile|Net\.WebClient", re.IGNORECASE),
     "загрузка содержимого из сети внутри скрипта"),
    (re.compile(rb"FromBase64String", re.IGNORECASE), "декодирование base64 внутри скрипта"),
    (re.compile(rb"Hidden|WindowStyle\s+Hidden", re.IGNORECASE), "запуск в скрытом окне"),
    (re.compile(rb"bypass", re.IGNORECASE), "признаки обхода политики выполнения"),
]


def _shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    occurrences = [0] * 256
    for b in data:
        occurrences[b] += 1
    entropy = 0.0
    length = len(data)
    for count in occurrences:
        if count == 0:
            continue
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def _analyze_pe(path: str, result: HeuristicResult):
    if not _HAS_PEFILE:
        return
    try:
        pe = pefile.PE(path, fast_load=True)
        pe.parse_data_directories(directories=[
            pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_IMPORT"]
        ])
    except pefile.PEFormatError:
        return  # не PE-файл (например, переименованный) — не ошибка
    except Exception:
        return

    result.pe_analyzed = True

    # 1. Точка входа вне обычных секций кода
    try:
        ep = pe.OPTIONAL_HEADER.AddressOfEntryPoint
        ep_section = None
        for section in pe.sections:
            start = section.VirtualAddress
            end = start + max(section.Misc_VirtualSize, section.SizeOfRawData)
            if start <= ep < end:
                ep_section = section.Name.decode(errors="ignore").strip("\x00").lower()
                break
        if ep_section and not ep_section.startswith(".text") and not ep_section.startswith(".code"):
            result.add(15, f"точка входа находится в нетипичной секции ({ep_section or 'не определена'})")
    except Exception:
        pass

    # 2. Секции, типичные для упаковщиков/протекторов
    try:
        for section in pe.sections:
            name = section.Name.decode(errors="ignore").strip("\x00").lower()
            if name in PACKER_SECTION_NAMES:
                result.add(10, f"обнаружена секция упаковщика/протектора ({name})")
                break
    except Exception:
        pass

    # 3. Высокая энтропия секций — признак упаковки/шифрования кода
    try:
        for section in pe.sections:
            data = section.get_data()
            if len(data) < 64:
                continue
            entropy = _shannon_entropy(data)
            if entropy > 7.5:
                name = section.Name.decode(errors="ignore").strip("\x00")
                result.add(12, f"секция {name} имеет очень высокую энтропию ({entropy:.2f}) — возможна упаковка/шифрование")
                break
    except Exception:
        pass

    # 4. Подозрительная комбинация импортов (инъекция в процессы)
    try:
        imported = set()
        if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
            for entry in pe.DIRECTORY_ENTRY_IMPORT:
                for imp in entry.imports:
                    if imp.name:
                        imported.add(imp.name.decode(errors="ignore"))
        hit = COMMON_SUSPICIOUS_IMPORTS & imported
        if len(hit) >= 3:
            result.add(25, "комбинация импортов, типичная для внедрения кода в другой процесс: " + ", ".join(sorted(hit)))
        elif len(hit) >= 1:
            result.add(8, "присутствуют функции, иногда используемые для внедрения кода: " + ", ".join(sorted(hit)))
    except Exception:
        pass

    # 5. Отсутствие таблицы импорта вообще (нетипично для обычных программ)
    try:
        if not hasattr(pe, "DIRECTORY_ENTRY_IMPORT") or not pe.DIRECTORY_ENTRY_IMPORT:
            result.add(6, "отсутствует таблица импортируемых функций")
    except Exception:
        pass


def _analyze_script(path: str, result: HeuristicResult):
    try:
        with open(path, "rb") as f:
            data = f.read(512 * 1024)  # первых 512КБ достаточно для эвристики
    except (OSError, PermissionError):
        return
    for pattern, reason in SUSPICIOUS_SCRIPT_PATTERNS:
        if pattern.search(data):
            result.add(10, reason)


def _analyze_location(path: str, result: HeuristicResult):
    norm = path.lower().replace("/", "\\")
    for hint in config.SUSPICIOUS_LOCATION_HINTS:
        if hint in norm:
            result.add(5, f"файл находится в каталоге, часто используемом для временных/загруженных файлов ({hint.strip(chr(92))})")
            break


def analyze_file(path: str) -> HeuristicResult:
    result = HeuristicResult()
    ext = os.path.splitext(path)[1].lower()

    if ext in config.EXECUTABLE_EXTENSIONS:
        _analyze_pe(path, result)
    elif ext in config.SCRIPT_EXTENSIONS:
        _analyze_script(path, result)

    _analyze_location(path, result)

    # ограничиваем эвристический вклад разумным потолком —
    # финальный балл всё равно формирует риск-движок вместе с сигнатурами
    result.score = min(result.score, 70)
    return result
