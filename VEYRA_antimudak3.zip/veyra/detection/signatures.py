"""
VEYRA Database (signature layer) / VEYRA Detection — сигнатурный анализ.

Важно честно: движок проверяет файлы ТОЛЬКО против той базы хэшей,
которая реально загружена в локальную БД (таблица signatures).
При первой установке эта база пуста — VEYRA не поставляется с готовой
базой вредоносных хэшей (её нужно наполнять через VEYRA Updater или
вручную), поэтому "сигнатурный результат: угроз не найдено" на чистой
базе означает "совпадений по известным хэшам нет", а не "файл безопасен
по всем показателям" — за это отвечает эвристика и риск-движок.
"""

import hashlib
from dataclasses import dataclass
from typing import Optional


@dataclass
class HashSet:
    md5: str
    sha1: str
    sha256: str


def compute_hashes(path: str, chunk_size: int = 1024 * 1024) -> Optional[HashSet]:
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                md5.update(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
    except (OSError, PermissionError):
        return None
    return HashSet(md5.hexdigest(), sha1.hexdigest(), sha256.hexdigest())


@dataclass
class SignatureMatch:
    matched: bool
    detect_name: Optional[str] = None
    severity: Optional[str] = None
    matched_hash: Optional[str] = None


def check_against_db(db, hashes: HashSet) -> SignatureMatch:
    """MD5 используется только для совместимости/идентификации — приоритет
    у SHA-256, затем SHA-1, затем MD5 (как указано в требованиях)."""
    row = db.lookup_signature(hashes.sha256, hashes.sha1, hashes.md5)
    if row:
        return SignatureMatch(
            matched=True,
            detect_name=row["detect_name"],
            severity=row["severity"],
            matched_hash=row["hash"],
        )
    return SignatureMatch(matched=False)
