"""
VEYRA — проверка цифровой подписи (Authenticode).

Честно: для настоящей проверки Authenticode нужен вызов WinVerifyTrust
из Windows API. Делаем это через ctypes (без сторонних библиотек типа
pywin32, чтобы не плодить лишние зависимости). На не-Windows платформах
(например, при разработке) функция возвращает "Не проверено".

Результат: "Подписан" / "Не подписан" / "Подпись недействительна" / "Не проверено"
Отсутствие подписи НЕ используется само по себе как признак вредоносности —
это учитывает только VEYRA Risk Engine, и то с небольшим весом.
"""

from core.config import IS_WINDOWS

STATUS_SIGNED = "Подписан"
STATUS_UNSIGNED = "Не подписан"
STATUS_INVALID = "Подпись недействительна"
STATUS_UNKNOWN = "Не проверено"

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    WINTRUST_ACTION_GENERIC_VERIFY_V2 = (
        "{00AAC56B-CD44-11d0-8CC2-00C04FC295EE}"
    )

    class _GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", ctypes.c_ulong),
            ("Data2", ctypes.c_ushort),
            ("Data3", ctypes.c_ushort),
            ("Data4", ctypes.c_ubyte * 8),
        ]

    def _guid_from_string(guid_str: str) -> _GUID:
        import uuid
        u = uuid.UUID(guid_str)
        g = _GUID()
        g.Data1, g.Data2, g.Data3 = u.time_low, u.time_mid, u.time_hi_version
        g.Data4[:] = u.bytes[8:]
        return g

    class _WINTRUST_FILE_INFO(ctypes.Structure):
        _fields_ = [
            ("cbStruct", wintypes.DWORD),
            ("pcwszFilePath", wintypes.LPCWSTR),
            ("hFile", wintypes.HANDLE),
            ("pgKnownSubject", ctypes.c_void_p),
        ]

    class _WINTRUST_DATA(ctypes.Structure):
        _fields_ = [
            ("cbStruct", wintypes.DWORD),
            ("pPolicyCallbackData", ctypes.c_void_p),
            ("pSIPClientData", ctypes.c_void_p),
            ("dwUIChoice", wintypes.DWORD),
            ("fdwRevocationChecks", wintypes.DWORD),
            ("dwUnionChoice", wintypes.DWORD),
            ("pFile", ctypes.POINTER(_WINTRUST_FILE_INFO)),
            ("dwStateAction", wintypes.DWORD),
            ("hWVTStateData", wintypes.HANDLE),
            ("pwszURLReference", wintypes.LPCWSTR),
            ("dwProvFlags", wintypes.DWORD),
            ("dwUIContext", wintypes.DWORD),
        ]

    WTD_UI_NONE = 2
    WTD_REVOKE_NONE = 0
    WTD_CHOICE_FILE = 1
    WTD_STATEACTION_VERIFY = 1
    WTD_STATEACTION_CLOSE = 2
    WTD_SAFER_FLAG = 0x100

    def check_signature(path: str) -> str:
        try:
            wintrust = ctypes.windll.wintrust
        except (AttributeError, OSError):
            return STATUS_UNKNOWN

        file_info = _WINTRUST_FILE_INFO()
        file_info.cbStruct = ctypes.sizeof(_WINTRUST_FILE_INFO)
        file_info.pcwszFilePath = path
        file_info.hFile = None
        file_info.pgKnownSubject = None

        data = _WINTRUST_DATA()
        data.cbStruct = ctypes.sizeof(_WINTRUST_DATA)
        data.dwUIChoice = WTD_UI_NONE
        data.fdwRevocationChecks = WTD_REVOKE_NONE
        data.dwUnionChoice = WTD_CHOICE_FILE
        data.pFile = ctypes.pointer(file_info)
        data.dwStateAction = WTD_STATEACTION_VERIFY
        data.dwProvFlags = WTD_SAFER_FLAG

        guid = _guid_from_string(WINTRUST_ACTION_GENERIC_VERIFY_V2)

        try:
            result = wintrust.WinVerifyTrust(
                None, ctypes.byref(guid), ctypes.byref(data)
            )
        except Exception:
            return STATUS_UNKNOWN
        finally:
            data.dwStateAction = WTD_STATEACTION_CLOSE
            try:
                wintrust.WinVerifyTrust(None, ctypes.byref(guid), ctypes.byref(data))
            except Exception:
                pass

        if result == 0:
            return STATUS_SIGNED
        # ERROR_NOT_SUPPORTED / TRUST_E_NOSIGNATURE и т.п. трактуем как "не подписан",
        # остальные негативные коды — как недействительную подпись
        if result in (-2146762751, -2146869232):  # TRUST_E_NOSIGNATURE варианты
            return STATUS_UNSIGNED
        return STATUS_INVALID

else:
    def check_signature(path: str) -> str:
        return STATUS_UNKNOWN
