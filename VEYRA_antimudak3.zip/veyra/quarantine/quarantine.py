"""
VEYRA Quarantine
Перемещает подозрительные файлы в изолированное хранилище так, чтобы
их нельзя было запустить обычным образом, и хранит метаданные для
восстановления или полного удаления.

Изоляция реализована простым XOR-обфускатором содержимого с фиксированным
ключом + сменой расширения на .veyraq. Это НЕ криптографическая защита —
цель не в шифровании, а в том, чтобы ОС и антивирусы (в т.ч. сам VEYRA)
не воспринимали файл как исполняемый, а пользователь не мог случайно
дважды кликнуть и запустить его. Реальные права/ACL также ограничиваются
там, где это доступно.
"""

import os
import shutil
import stat
from datetime import datetime

from core import config

_XOR_KEY = 0xA5  # намеренно простое, объявленное преобразование — не для секретности


def _transform(path_in: str, path_out: str):
    with open(path_in, "rb") as src, open(path_out, "wb") as dst:
        while True:
            chunk = src.read(1024 * 1024)
            if not chunk:
                break
            dst.write(bytes(b ^ _XOR_KEY for b in chunk))


class QuarantineManager:
    def __init__(self, db, logger_module):
        self.db = db
        self.logger = logger_module
        config.ensure_dirs()

    def quarantine_file(self, original_path: str, sha256: str, reason: str,
                         risk_score: int, risk_level: str, detect_name: str) -> int:
        filename = os.path.basename(original_path)
        stamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
        quarantine_name = f"{stamp}_{filename}.veyraq"
        quarantine_path = os.path.join(config.QUARANTINE_DIR, quarantine_name)

        try:
            _transform(original_path, quarantine_path)
            # ограничиваем права на файл в карантине (только чтение для владельца)
            try:
                os.chmod(quarantine_path, stat.S_IREAD)
            except OSError:
                pass
            os.remove(original_path)
        except (OSError, PermissionError) as e:
            self.logger.log_event(
                self.db, self.logger.EVENT_SYSTEM,
                f"Не удалось поместить файл в карантин ({original_path}): {e}",
                severity="ERROR",
            )
            raise

        entry_id = self.db.add_quarantine_entry(
            original_path=original_path,
            filename=filename,
            sha256=sha256,
            reason=reason,
            risk_score=risk_score,
            risk_level=risk_level,
            detect_name=detect_name,
            quarantine_path=quarantine_path,
        )

        self.logger.log_event(
            self.db, self.logger.EVENT_BLOCK,
            f"Объект помещён в карантин: {filename} ({detect_name}, риск {risk_score}/100)",
            severity="WARNING",
        )
        return entry_id

    def restore(self, entry_id: int) -> bool:
        entry = self.db.get_quarantine_entry(entry_id)
        if not entry or entry["status"] != "В карантине":
            return False

        target_dir = os.path.dirname(entry["original_path"])
        try:
            os.makedirs(target_dir, exist_ok=True)
            _transform(entry["quarantine_path"], entry["original_path"])
            os.remove(entry["quarantine_path"])
        except (OSError, PermissionError) as e:
            self.logger.log_event(
                self.db, self.logger.EVENT_SYSTEM,
                f"Не удалось восстановить файл из карантина: {e}", severity="ERROR",
            )
            return False

        self.db.update_quarantine_status(entry_id, "Восстановлен")
        self.logger.log_event(
            self.db, self.logger.EVENT_SYSTEM,
            f"Файл восстановлен из карантина: {entry['filename']}", severity="INFO",
        )
        return True

    def delete(self, entry_id: int) -> bool:
        entry = self.db.get_quarantine_entry(entry_id)
        if not entry:
            return False
        try:
            if os.path.exists(entry["quarantine_path"]):
                os.remove(entry["quarantine_path"])
        except (OSError, PermissionError) as e:
            self.logger.log_event(
                self.db, self.logger.EVENT_SYSTEM,
                f"Не удалось удалить объект карантина: {e}", severity="ERROR",
            )
            return False

        self.db.update_quarantine_status(entry_id, "Удалён")
        self.logger.log_event(
            self.db, self.logger.EVENT_SYSTEM,
            f"Объект карантина удалён безвозвратно: {entry['filename']}", severity="INFO",
        )
        return True

    def delete_all(self):
        for entry in self.db.list_quarantine(status="В карантине"):
            self.delete(entry["id"])

    def list_all(self):
        return self.db.list_quarantine()
