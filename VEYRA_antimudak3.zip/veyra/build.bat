@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   VEYRA antimudak - build
echo ============================================
echo.

if not exist "main.py" (
    echo ERROR: main.py not found in this folder.
    echo Make sure this .bat file is INSIDE the extracted "veyra" folder,
    echo next to main.py and requirements.txt.
    pause
    exit /b 1
)

echo [1/3] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found in PATH.
    echo Install Python from python.org and check "Add python.exe to PATH".
    pause
    exit /b 1
)

echo [2/3] Installing dependencies, this can take a couple of minutes...
python -m pip install --user -q -r requirements.txt
if errorlevel 1 (
    echo ERROR: failed to install dependencies. See messages above.
    pause
    exit /b 1
)

echo [3/3] Building VEYRA antimudak.exe, this can take 1-3 minutes...
python -m PyInstaller --name "VEYRA antimudak" --onefile --windowed --noconfirm --add-data "core;core" --add-data "detection;detection" --add-data "quarantine;quarantine" --add-data "scanner;scanner" --add-data "realtime;realtime" --add-data "autostart;autostart" --add-data "ui;ui" main.py

if errorlevel 1 (
    echo ERROR during build. See messages above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Done. Opening the folder with the exe file...
echo ============================================
start "" "%~dp0dist"
pause
